declare module '../../assets/svg/SectionSvg';
declare module '../../assets/svg/Brackets';