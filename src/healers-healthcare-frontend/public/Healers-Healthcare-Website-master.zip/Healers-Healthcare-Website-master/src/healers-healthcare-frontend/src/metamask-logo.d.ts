// src/metamask-logo.d.ts
declare module '@metamask/logo';