/// <reference types="vite/client" />

declare module 'react-anchor-link-smooth-scroll';
declare module '../assets';
declare module '*.png';
declare module '*.jpg';

declare module './FeatureSection/Feature';
declare module './3dPinReal';
declare module './ScrollHero';
declare module './BackgroundBoxes';


